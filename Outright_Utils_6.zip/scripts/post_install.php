<?php
function post_install(){
$msg ="<h2> Thanks for using our  Core Outright Utils Package , This Package is amazing and life saver for developers.
Learn   <a href ='https://www.outrightcrm.com/2018/07/23/suitecrm_outright_tricks/' target='_blank'> Here more  </a>
</h2>
Fee free to write us at sales@outrightcrm.com for all of your queries. Thank you for loving us!
";


echo $msg;
}
