<?php
// created: 2018-11-14 12:05:36
$app_list_strings['date_range_search_dom'] = array (
  '=' => 'Equals',
  'not_equal' => 'Not On',
  'greater_than' => 'After',
  'less_than' => 'Before',
  'last_7_days' => 'Last 7 Days',
  'next_7_days' => 'Next 7 Days',
  'last_30_days' => 'Last 30 Days',
  'next_30_days' => 'Next 30 Days',
  'last_month' => 'Last Month',
  'this_month' => 'This Month',
  'next_month' => 'Next Month',
  'last_year' => 'Last Year',
  'this_year' => 'This Year',
  'next_year' => 'Next Year',
  'between' => 'Is Between',
);