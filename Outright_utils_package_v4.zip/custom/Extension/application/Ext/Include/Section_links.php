<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['outr_Section_links'] = 'outr_Section_links';
$beanFiles['outr_Section_links'] = 'modules/outr_Section_links/outr_Section_links.php';
$moduleList[] = 'outr_Section_links';
$modInvisList[] = 'outr_Section_links';
$adminOnlyList[] = 'outr_Section_links';
?>