<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['outr_admin_section'] = 'outr_admin_section';
$beanFiles['outr_admin_section'] = 'modules/outr_admin_section/outr_admin_section.php';
$moduleList[] = 'outr_admin_section';
$modInvisList[] = 'outr_admin_section';
$adminOnlyList[] = 'outr_admin_section';
?>