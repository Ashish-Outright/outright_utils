<?php
$entry_point_registry['get_admin_sections'] = array(
    'file' => 'custom/modules/outr_Section_links/get_admin_sections.php',
    'auth' => true
);
