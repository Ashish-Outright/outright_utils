<?php
$entry_point_registry['merge_admin_with_sugar'] = array(
    'file' => 'custom/modules/Administration/merge_admins_with_sugar.php',
    'auth' => true
);

