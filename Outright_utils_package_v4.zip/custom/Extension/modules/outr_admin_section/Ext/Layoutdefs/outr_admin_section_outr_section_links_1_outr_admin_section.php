<?php
 // created: 2018-08-09 06:59:15
$layout_defs["outr_admin_section"]["subpanel_setup"]['outr_admin_section_outr_section_links_1'] = array (
  'order' => 100,
  'module' => 'outr_Section_links',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OUTR_ADMIN_SECTION_OUTR_SECTION_LINKS_1_FROM_OUTR_SECTION_LINKS_TITLE',
  'get_subpanel_data' => 'outr_admin_section_outr_section_links_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
