<?php
// created: 2018-08-09 06:59:15
$dictionary["outr_admin_section"]["fields"]["outr_admin_section_outr_section_links_1"] = array (
  'name' => 'outr_admin_section_outr_section_links_1',
  'type' => 'link',
  'relationship' => 'outr_admin_section_outr_section_links_1',
  'source' => 'non-db',
  'module' => 'outr_Section_links',
  'bean_name' => 'outr_Section_links',
  'side' => 'right',
  'vname' => 'LBL_OUTR_ADMIN_SECTION_OUTR_SECTION_LINKS_1_FROM_OUTR_SECTION_LINKS_TITLE',
);
