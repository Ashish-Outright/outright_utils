<?php
// created: 2018-09-04 18:48:38
$mod_strings = array (
  'LBL_OUTR_ADMIN_SECTION_OUTR_SECTION_LINKS_1_FROM_OUTR_SECTION_LINKS_TITLE' => 'Section Links',
);