<?php
// created: 2018-11-06 12:43:29
$mod_strings = array (
  'LBL_DESCRIPTION' => 'Description ',
);